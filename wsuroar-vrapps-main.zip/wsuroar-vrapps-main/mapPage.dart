import 'dart:html';

import 'package:flutter/material.dart';

class Map extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('MAP OF WSU'),
        centerTitle: true,
        backgroundColor: Colors.red,
      ),
      body: Center(
          child: Image(
              image: NetworkImage(
                  'https://s3.wp.wsu.edu/uploads/sites/1121/2016/09/campusmap-1188x931.png'))),
    );
  }
}
