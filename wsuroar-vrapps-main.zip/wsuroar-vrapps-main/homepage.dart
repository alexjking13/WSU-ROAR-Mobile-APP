import 'package:flutter/material.dart';
import 'package:flutter_application_1/homepage.dart';
import 'package:flutter_application_1/location_page.dart';
import 'package:flutter_application_1/locationMenuPage.dart';
import 'package:flutter_application_1/picture_page.dart';
import 'package:flutter_application_1/currentlocationselectpage.dart';
import 'package:flutter_application_1/main.dart';

class Home extends StatefulWidget {
  const Home({super.key});

  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {

  @override
  Widget build(BuildContext context) {


    return Scaffold(
        appBar: AppBar(
          title: const Text('CougDirect'),
          centerTitle: true,
          // backgroundColor: Colors.red,
        ),
        body: Column(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            const Image(
              image: AssetImage('assets/wsuroar-1.png'),
            ),
            Text("Current Location is: "),
            ElevatedButton(
              onPressed: () {
                Navigator.pushNamed(context, '/selectCLpage');
              },
              style: ElevatedButton.styleFrom(
                  // backgroundColor: Colors.red
                  ),
              child: const Text('Set Current Location'),
            ),
            ElevatedButton(
            onPressed: () {
            Navigator.push(context, MaterialPageRoute(builder: (context) => destinations()));
            },
            style: ElevatedButton.styleFrom(
            // backgroundColor: Colors.red
            ),
            child: const Text('Check Out Our Locations!'),
            ),
          ],
        ));
  }
}
