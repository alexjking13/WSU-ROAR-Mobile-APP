
please do the following 
  -create an 'assets' folder in the from the main project directory
  -download the wsuroar-1.png file and place it in the 'assets' folder
  -WITHIN the pubspec.yaml file,  add '-assets/' to line 64 within the assets section
